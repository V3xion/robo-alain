export const Footer = () => {
  return (
    <footer className="py-8 border-t border-border">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="font-display text-2xl font-bold text-gold-gradient">
            CESOX
          </div>
          <p className="text-muted-foreground text-sm">
            © {new Date().getFullYear()} Cesox Barbershop. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};
