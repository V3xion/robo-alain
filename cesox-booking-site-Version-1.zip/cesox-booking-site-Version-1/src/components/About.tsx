import { Award, Clock, Users } from "lucide-react";

const stats = [
  { icon: Users, value: "5000+", label: "Happy Clients" },
  { icon: Award, value: "15+", label: "Years Experience" },
  { icon: Clock, value: "7", label: "Days a Week" },
];

export const About = () => {
  return (
    <section id="about" className="section-padding bg-secondary">
      <div className="container mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <div>
            <span className="text-gold font-medium tracking-[0.2em] uppercase text-sm">
              About Us
            </span>
            <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-6">
              The Art of <span className="text-gold-gradient">Barbering</span>
            </h2>
            <p className="text-muted-foreground text-lg mb-6">
              At Cesox, we believe that a great haircut is more than just a service—it's an experience. 
              Our master barbers combine traditional techniques with modern trends to deliver exceptional results.
            </p>
            <p className="text-muted-foreground mb-8">
              Founded on the principles of craftsmanship and attention to detail, we've been serving 
              our community for over 15 years. Every visit to Cesox is a journey into refined grooming.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center">
                  <stat.icon className="w-8 h-8 text-gold mx-auto mb-2" />
                  <div className="font-display text-3xl font-bold text-gold-gradient">
                    {stat.value}
                  </div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Visual Element */}
          <div className="relative">
            <div className="aspect-square rounded-2xl glass-card p-8 flex items-center justify-center">
              <div className="text-center">
                <div className="font-display text-8xl md:text-9xl font-bold text-gold-gradient opacity-20">
                  C
                </div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className="font-display text-4xl md:text-5xl font-bold mb-2">
                      EST.
                    </div>
                    <div className="font-display text-5xl md:text-6xl font-bold text-gold-gradient">
                      2009
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* Decorative corners */}
            <div className="absolute -top-4 -left-4 w-20 h-20 border-l-2 border-t-2 border-gold" />
            <div className="absolute -bottom-4 -right-4 w-20 h-20 border-r-2 border-b-2 border-gold" />
          </div>
        </div>
      </div>
    </section>
  );
};
