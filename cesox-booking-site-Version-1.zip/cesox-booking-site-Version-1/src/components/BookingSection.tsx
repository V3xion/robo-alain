import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, User, Scissors, Check } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { PhoneInput } from "@/components/PhoneInput";
import { supabase } from "@/integrations/supabase/client";

interface Service {
  id: string;
  name: string;
  price: string;
  is_active: boolean;
}

interface Barber {
  id: string;
  name: string;
  is_active: boolean;
}

const timeSlots = [
  "9:00 AM", "9:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM",
  "12:00 PM", "12:30 PM", "1:00 PM", "1:30 PM", "2:00 PM", "2:30 PM",
  "3:00 PM", "3:30 PM", "4:00 PM", "4:30 PM", "5:00 PM", "5:30 PM",
];

export const BookingSection = () => {
  const [step, setStep] = useState(1);
  const [selectedService, setSelectedService] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedTime, setSelectedTime] = useState("");
  const [selectedBarber, setSelectedBarber] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Dynamic data from database
  const [services, setServices] = useState<Service[]>([]);
  const [barbers, setBarbers] = useState<Barber[]>([]);

  useEffect(() => {
    fetchServices();
    fetchBarbers();

    const servicesChannel = supabase
      .channel("booking-services-live")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "services" },
        () => fetchServices()
      )
      .subscribe();

    const barbersChannel = supabase
      .channel("booking-barbers-live")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "barbers" },
        () => fetchBarbers()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(servicesChannel);
      supabase.removeChannel(barbersChannel);
    };
  }, []);

  const fetchServices = async () => {
    const { data, error } = await supabase
      .from('services')
      .select('*')
      .eq('is_active', true)
      .order('created_at', { ascending: true });
    
    if (!error && data) {
      setServices(data);
    }
  };

  const fetchBarbers = async () => {
    const { data, error } = await supabase
      .from('barbers')
      .select('*')
      .eq('is_active', true)
      .order('created_at', { ascending: true });
    
    if (!error && data) {
      setBarbers(data);
    }
  };

  // Generate next 14 days for booking
  const getNextDays = () => {
    const days = [];
    const today = new Date();
    for (let i = 1; i <= 14; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      days.push({
        date: date.toISOString().split("T")[0],
        display: date.toLocaleDateString("en-US", {
          weekday: "short",
          month: "short",
          day: "numeric",
        }),
      });
    }
    return days;
  };

  const isPhoneValid = phone.length === 10 && phone.startsWith('05');

  const handleSubmit = async () => {
    if (!name || !phone) {
      toast({
        title: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    if (!isPhoneValid) {
      toast({
        title: "Please enter a valid UAE phone number (05XXXXXXXX)",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    const selectedServiceData = services.find(s => s.id === selectedService);
    const selectedBarberData = barbers.find(b => b.id === selectedBarber);

   // Use edge function for secure booking creation with validation and rate limiting
     const response = await fetch(
       `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-booking`,
       {
         method: 'POST',
         headers: {
           'Content-Type': 'application/json',
           'apikey': import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
         },
         body: JSON.stringify({
           customer_name: name.trim(),
           customer_phone: phone,
           service_id: selectedService,
           service_name: selectedServiceData?.name || '',
           service_price: selectedServiceData?.price || '',
           barber_id: selectedBarber,
           barber_name: selectedBarberData?.name || '',
           booking_date: selectedDate,
           booking_time: selectedTime,
         }),
       }
     );
 
     const result = await response.json();

    setIsSubmitting(false);

     if (!response.ok || result.error) {
      toast({
         title: result.error || "Error creating booking",
         description: response.status === 429 
           ? "You've made too many booking attempts. Please wait and try again."
           : "Please check your information and try again.",
        variant: "destructive",
      });
      return;
    }
    
    toast({
      title: "Booking Confirmed!",
      description: `Your appointment has been scheduled for ${selectedDate} at ${selectedTime}`,
    });
    
    // Reset form
    setStep(1);
    setSelectedService("");
    setSelectedDate("");
    setSelectedTime("");
    setSelectedBarber("");
    setName("");
    setPhone("");
  };

  return (
    <section id="book" className="section-padding">
      <div className="container mx-auto max-w-4xl">
        {/* Section Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Calendar className="w-5 h-5 text-gold" />
            <span className="text-gold font-medium tracking-[0.2em] uppercase text-sm">
              Book Now
            </span>
          </div>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
            Schedule Your <span className="text-gold-gradient">Visit</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Book your appointment online and skip the wait
          </p>
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-center gap-4 mb-12">
          {[1, 2, 3, 4].map((s) => (
            <div key={s} className="flex items-center gap-2">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold transition-all ${
                  step >= s
                    ? "gold-gradient text-primary-foreground"
                    : "bg-secondary text-muted-foreground"
                }`}
              >
                {step > s ? <Check className="w-5 h-5" /> : s}
              </div>
              {s < 4 && (
                <div
                  className={`w-12 h-0.5 ${
                    step > s ? "bg-gold" : "bg-border"
                  }`}
                />
              )}
            </div>
          ))}
        </div>

        {/* Booking Form */}
        <div className="glass-card rounded-2xl p-8">
          {/* Step 1: Select Service */}
          {step === 1 && (
            <div className="animate-fade-in">
              <div className="flex items-center gap-3 mb-6">
                <Scissors className="w-6 h-6 text-gold" />
                <h3 className="font-display text-2xl font-semibold">
                  Select Service
                </h3>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                {services.map((service) => (
                  <button
                    key={service.id}
                    onClick={() => setSelectedService(service.id)}
                    className={`p-4 rounded-lg border text-left transition-all ${
                      selectedService === service.id
                        ? "border-gold bg-gold/10"
                        : "border-border hover:border-gold/50"
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span className="font-medium">{service.name}</span>
                      <span className="text-gold font-semibold">
                        {service.price}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
              <Button
                variant="gold"
                size="lg"
                className="w-full mt-8"
                disabled={!selectedService}
                onClick={() => setStep(2)}
              >
                Continue
              </Button>
            </div>
          )}

          {/* Step 2: Select Date & Time */}
          {step === 2 && (
            <div className="animate-fade-in">
              <div className="flex items-center gap-3 mb-6">
                <Calendar className="w-6 h-6 text-gold" />
                <h3 className="font-display text-2xl font-semibold">
                  Select Date
                </h3>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
                {getNextDays().map((day) => (
                  <button
                    key={day.date}
                    onClick={() => setSelectedDate(day.display)}
                    className={`p-3 rounded-lg border text-center transition-all ${
                      selectedDate === day.display
                        ? "border-gold bg-gold/10"
                        : "border-border hover:border-gold/50"
                    }`}
                  >
                    <span className="text-sm">{day.display}</span>
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-3 mb-6">
                <Clock className="w-6 h-6 text-gold" />
                <h3 className="font-display text-2xl font-semibold">
                  Select Time
                </h3>
              </div>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
                {timeSlots.map((time) => (
                  <button
                    key={time}
                    onClick={() => setSelectedTime(time)}
                    className={`p-2 rounded-lg border text-center text-sm transition-all ${
                      selectedTime === time
                        ? "border-gold bg-gold/10"
                        : "border-border hover:border-gold/50"
                    }`}
                  >
                    {time}
                  </button>
                ))}
              </div>

              <div className="flex gap-4 mt-8">
                <Button
                  variant="goldOutline"
                  size="lg"
                  className="flex-1"
                  onClick={() => setStep(1)}
                >
                  Back
                </Button>
                <Button
                  variant="gold"
                  size="lg"
                  className="flex-1"
                  disabled={!selectedDate || !selectedTime}
                  onClick={() => setStep(3)}
                >
                  Continue
                </Button>
              </div>
            </div>
          )}

          {/* Step 3: Select Barber */}
          {step === 3 && (
            <div className="animate-fade-in">
              <div className="flex items-center gap-3 mb-6">
                <User className="w-6 h-6 text-gold" />
                <h3 className="font-display text-2xl font-semibold">
                  Choose Your Barber
                </h3>
              </div>
              <div className="grid sm:grid-cols-3 gap-4">
                {barbers.map((barber) => (
                  <button
                    key={barber.id}
                    onClick={() => setSelectedBarber(barber.id)}
                    className={`p-6 rounded-lg border text-center transition-all ${
                      selectedBarber === barber.id
                        ? "border-gold bg-gold/10"
                        : "border-border hover:border-gold/50"
                    }`}
                  >
                    <div className="w-16 h-16 rounded-full bg-secondary mx-auto mb-3 flex items-center justify-center">
                      <User className="w-8 h-8 text-muted-foreground" />
                    </div>
                    <span className="font-medium">{barber.name}</span>
                  </button>
                ))}
              </div>
              <div className="flex gap-4 mt-8">
                <Button
                  variant="goldOutline"
                  size="lg"
                  className="flex-1"
                  onClick={() => setStep(2)}
                >
                  Back
                </Button>
                <Button
                  variant="gold"
                  size="lg"
                  className="flex-1"
                  disabled={!selectedBarber}
                  onClick={() => setStep(4)}
                >
                  Continue
                </Button>
              </div>
            </div>
          )}

          {/* Step 4: Contact Info */}
          {step === 4 && (
            <div className="animate-fade-in">
              <div className="flex items-center gap-3 mb-6">
                <User className="w-6 h-6 text-gold" />
                <h3 className="font-display text-2xl font-semibold">
                  Your Details
                </h3>
              </div>
              <div className="space-y-4 mb-8">
                <div>
                  <label className="block text-sm font-medium mb-2">Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Your name"
                    className="w-full px-4 py-3 rounded-lg bg-secondary border border-border focus:border-gold focus:outline-none transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Phone (UAE)</label>
                  <PhoneInput
                    value={phone}
                    onChange={setPhone}
                    placeholder="05XXXXXXXX"
                    className="w-full px-4 py-3 rounded-lg bg-secondary border border-border focus:border-gold focus:outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Booking Summary */}
              <div className="p-4 rounded-lg bg-secondary/50 mb-8">
                <h4 className="font-semibold mb-3">Booking Summary</h4>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p>Service: {services.find(s => s.id === selectedService)?.name}</p>
                  <p>Date: {selectedDate}</p>
                  <p>Time: {selectedTime}</p>
                  <p>Barber: {barbers.find(b => b.id === selectedBarber)?.name}</p>
                </div>
              </div>

              <div className="flex gap-4">
                <Button
                  variant="goldOutline"
                  size="lg"
                  className="flex-1"
                  onClick={() => setStep(3)}
                >
                  Back
                </Button>
                <Button
                  variant="gold"
                  size="lg"
                  className="flex-1"
                  onClick={handleSubmit}
                  disabled={isSubmitting || !name || !isPhoneValid}
                >
                  {isSubmitting ? "Booking..." : "Confirm Booking"}
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
