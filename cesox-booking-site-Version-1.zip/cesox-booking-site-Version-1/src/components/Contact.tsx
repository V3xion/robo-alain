import { MapPin, Phone, Clock, Instagram, Facebook, Twitter } from "lucide-react";

export const Contact = () => {
  return (
    <section id="contact" className="section-padding">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <span className="text-gold font-medium tracking-[0.2em] uppercase text-sm">
            Get In Touch
          </span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-4">
            Visit <span className="text-gold-gradient">Cesox</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Drop by our shop or give us a call. We're always happy to see you.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          {/* Location */}
          <div className="glass-card rounded-xl p-8 text-center hover:border-gold/50 transition-all">
            <MapPin className="w-10 h-10 text-gold mx-auto mb-4" />
            <h3 className="font-display text-xl font-semibold mb-3">Location</h3>
            <p className="text-muted-foreground">
              123 Main Street<br />
              Downtown District<br />
              New York, NY 10001
            </p>
          </div>

          {/* Hours */}
          <div className="glass-card rounded-xl p-8 text-center hover:border-gold/50 transition-all">
            <Clock className="w-10 h-10 text-gold mx-auto mb-4" />
            <h3 className="font-display text-xl font-semibold mb-3">Hours</h3>
            <p className="text-muted-foreground">
              Mon - Fri: 9AM - 8PM<br />
              Saturday: 9AM - 6PM<br />
              Sunday: 10AM - 5PM
            </p>
          </div>

          {/* Contact */}
          <div className="glass-card rounded-xl p-8 text-center hover:border-gold/50 transition-all">
            <Phone className="w-10 h-10 text-gold mx-auto mb-4" />
            <h3 className="font-display text-xl font-semibold mb-3">Contact</h3>
            <p className="text-muted-foreground">
              Phone: (555) 123-4567<br />
              Email: info@cesox.com<br />
              <span className="text-gold">Walk-ins Welcome</span>
            </p>
          </div>
        </div>

        {/* Social Links */}
        <div className="flex justify-center gap-6 mt-12">
          <a
            href="#"
            className="w-12 h-12 rounded-full border border-border hover:border-gold hover:bg-gold/10 flex items-center justify-center transition-all"
          >
            <Instagram className="w-5 h-5 text-muted-foreground hover:text-gold" />
          </a>
          <a
            href="#"
            className="w-12 h-12 rounded-full border border-border hover:border-gold hover:bg-gold/10 flex items-center justify-center transition-all"
          >
            <Facebook className="w-5 h-5 text-muted-foreground hover:text-gold" />
          </a>
          <a
            href="#"
            className="w-12 h-12 rounded-full border border-border hover:border-gold hover:bg-gold/10 flex items-center justify-center transition-all"
          >
            <Twitter className="w-5 h-5 text-muted-foreground hover:text-gold" />
          </a>
        </div>
      </div>
    </section>
  );
};
