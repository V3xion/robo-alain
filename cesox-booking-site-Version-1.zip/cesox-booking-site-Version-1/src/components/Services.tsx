import { useEffect, useState } from "react";
import { Scissors, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Service {
  id: string;
  name: string;
  price: string;
  description?: string | null;
  duration?: string | null;
  is_active: boolean;
}

export const Services = () => {
  const [services, setServices] = useState<Service[]>([]);

  useEffect(() => {
    const fetchServices = async () => {
      const { data } = await supabase
        .from("services")
        .select("*")
        .eq("is_active", true)
        .order("created_at", { ascending: true });

      setServices(data || []);
    };

    fetchServices();

    const channel = supabase
      .channel("services-live")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "services" },
        () => fetchServices()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return (
    <section id="services" className="section-padding bg-secondary">
      <div className="container mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Scissors className="w-5 h-5 text-gold" />
            <span className="text-gold font-medium tracking-[0.2em] uppercase text-sm">
              Our Services
            </span>
            <Scissors className="w-5 h-5 text-gold rotate-180" />
          </div>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
            Premium <span className="text-gold-gradient">Grooming</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Experience the art of traditional barbering with modern techniques
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.length === 0 ? (
            <div className="glass-card rounded-lg p-8 text-center text-muted-foreground md:col-span-2 lg:col-span-3">
              Services will appear here once they are added in the admin panel.
            </div>
          ) : (
            services.map((service, index) => (
              <div
                key={service.id}
                className="glass-card rounded-lg p-6 hover:border-gold/50 transition-all duration-300 group"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="font-display text-xl font-semibold group-hover:text-gold transition-colors">
                      {service.name}
                    </h3>
                    <p className="text-muted-foreground text-sm mt-1">
                      {service.description || "Premium grooming tailored for you."}
                    </p>
                  </div>
                  <Sparkles className="w-5 h-5 text-gold/50 group-hover:text-gold transition-colors" />
                </div>
                <div className="flex justify-between items-center pt-4 border-t border-border">
                  <span className="text-2xl font-display font-bold text-gold">
                    {service.price}
                  </span>
                  <span className="text-sm text-muted-foreground">
                    {service.duration || "Ask for timing details"}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </section>
  );
};
